import os
import json
import time
import requests
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

TOPICS = [
    "Machine Learning basics",
    "Artificial Intelligence overview",
    "Data Structures and Algorithms introduction",
    "Operating System concepts",
    "Computer Networks fundamentals"
]

def fetch_results(query, max_results=3):
    results = []
    with DDGS() as ddgs:
        for r in ddgs.text(query, max_results=max_results):
            results.append(r["href"])
    return results

def extract_text(url):
    try:
        response = requests.get(url, headers=HEADERS, timeout=5)
        soup = BeautifulSoup(response.text, "html.parser")
        paragraphs = soup.find_all("p")
        text = " ".join(p.get_text() for p in paragraphs)
        return text.strip()
    except Exception as e:
        print(f"Failed to extract from {url}: {e}")
        return ""

def scrape_topic(topic):
    print(f"🔍 Scraping: {topic}")
    urls = fetch_results(topic, max_results=3)
    entries = []
    for url in urls:
        print(f"  📄 Fetching: {url}")
        content = extract_text(url)
        if content:
            entries.append({
                "topic": topic,
                "url": url,
                "content": content
            })
        time.sleep(1)  # avoid getting blocked
    return entries

def load_existing_dataset(filename):
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def save_dataset(filename, new_data):
    existing = load_existing_dataset(filename)
    combined = existing + new_data
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(combined, f, indent=2)
    print(f"✅ Saved {len(new_data)} new entries to {filename}")

if __name__ == "__main__":
    all_data = []
    for topic in TOPICS:
        topic_data = scrape_topic(topic)
        all_data.extend(topic_data)

    save_dataset("dataset.json", all_data)
