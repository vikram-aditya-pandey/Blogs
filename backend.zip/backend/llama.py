import json
import requests

LLAMA_API_URL = "http://localhost:11434/api/generate"

def query_llama(prompt: str) -> str:
    try:
        response = requests.post(
            LLAMA_API_URL,
            json={
                "model": "llama3.2",
                "prompt": prompt,
                "stream": False
            }
        )
        response.raise_for_status()
        return response.json()["response"].strip()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error comparing content: {e}")
        return ""

def check_plagiarism(user_blog: str):
    with open("dataset.json", "r", encoding="utf-8") as f:
        dataset = json.load(f)

    print("\n🔍 Plagiarism Results:")

    for entry in dataset:
        topic = entry.get("topic", "Unknown Topic")
        print(f"📤 Sending prompt for topic: {topic}")

        for para in entry.get("content", []):
            prompt = f"Compare the following paragraph with the given blog. If they convey the same meaning or content, reply with only 'Plagiarized'. Otherwise, reply with only 'Original'.\n\nBlog:\n{user_blog}\n\nParagraph:\n{para}"
            result = query_llama(prompt)

            if result.lower().strip() == "plagiarized":
                print(f"⚠️  Plagiarized content found from: {entry.get('url', 'Unknown URL')}")
                break  # Stop checking this entry if any paragraph is plagiarized

if __name__ == "__main__":
    user_blog = input("📝 Enter blog content to check:\n")
    check_plagiarism(user_blog)
