from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from app import checker

app = FastAPI()

origins = ["http://localhost:3000", "http://localhost:5173"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Data Models ===
class BlogInput(BaseModel):
    title: str
    content: str
    mode: str = "nltk"  # default mode

class SaveInput(BaseModel):
    title: str
    content: str

# === Routes ===
@app.post("/check_plagiarism/")
async def check_plagiarism(data: BlogInput):
    result = checker.check_plagiarism(data.title, data.content, data.mode)
    similarity = result.get("average_score", 0.0)
    return {
        "is_plagiarized": result["is_plagiarized"],
        "similarity": round(similarity * 100, 2),
        "sources": result.get("sources", []),
        "mode_used": result.get("mode_used", data.mode)
    }

@app.post("/save_blog/")
async def save_blog(data: SaveInput, request: Request):
    # 👇 This grabs the user's email from the cookie named 'username'
    author = request.cookies.get("username")
    if not author:
        raise HTTPException(status_code=400, detail="Missing user information")
    
    return checker.save_blog(data.title, data.content, author)

@app.get("/blogs/")
def get_blogs():
    return checker.get_all_blogs()

@app.get("/blogs/{blog_id}")
def get_blog(blog_id: int):
    blog = checker.get_blog_by_id(blog_id)
    if blog:
        return blog
    raise HTTPException(status_code=404, detail="Blog not found")
