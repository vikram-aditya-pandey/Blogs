from pydantic import BaseModel

class BlogInput(BaseModel):
    title: str
    content: str
    mode: str

class SaveBlogInput(BaseModel):
    title: str
    content: str
    author: str
