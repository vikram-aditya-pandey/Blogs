# import json
# from sentence_transformers import SentenceTransformer, util
# from duckduckgo_search import DDGS
# from bs4 import BeautifulSoup
# import requests
# import nltk
# import re

# nltk.download("punkt")

# model = SentenceTransformer("all-MiniLM-L6-v2")
# SERP_API_KEY = "b51af3fa02f19b02c6324d46ca4f9979f52d39817ade7fa29206ccac1220335f"
# LLAMA_API_URL = "http://localhost:11434/api/generate"

# def chunk_text(text, max_tokens=100):
#     from nltk.tokenize import sent_tokenize
#     sentences = sent_tokenize(text)
#     chunks, current_chunk = [], []
#     for sentence in sentences:
#         current_chunk.append(sentence)
#         if len(" ".join(current_chunk).split()) > max_tokens:
#             chunks.append(" ".join(current_chunk))
#             current_chunk = []
#     if current_chunk:
#         chunks.append(" ".join(current_chunk))
#     return chunks

# def search_snippets_ddg(query, max_results=5):
#     try:
#         with DDGS() as ddgs:
#             results = ddgs.text(query, max_results=max_results)
#             return [r["href"] for r in results if "href" in r]
#     except Exception as e:
#         print(f"❌ DDG failed: {e}")
#         return []

# def search_snippets_serpapi(query, max_results=5):
#     try:
#         url = "https://serpapi.com/search.json"
#         params = {
#             "q": query,
#             "api_key": SERP_API_KEY,
#             "engine": "google"
#         }
#         response = requests.get(url, params=params)
#         data = response.json()
#         sources = []
#         if "organic_results" in data:
#             for item in data["organic_results"][:max_results]:
#                 link = item.get("link")
#                 if link:
#                     sources.append(link)
#         return sources
#     except Exception as e:
#         print(f"❌ SerpAPI failed: {e}")
#         return []

# def scrape_text(url):
#     try:
#         headers = {"User-Agent": "Mozilla/5.0"}
#         html = requests.get(url, headers=headers, timeout=10).text
#         soup = BeautifulSoup(html, "html.parser")
#         text = soup.get_text(separator=" ", strip=True)
#         text = re.sub(r"\s+", " ", text)
#         return text
#     except Exception as e:
#         print(f"❌ Failed to fetch {url}: {e}")
#         return ""

# def query_llama(prompt: str) -> str:
#     try:
#         response = requests.post(
#             LLAMA_API_URL,
#             json={
#                 "model": "llama3.2",
#                 "prompt": prompt,
#                 "stream": False
#             }
#         )
#         response.raise_for_status()
#         return response.json()["response"].strip()
#     except requests.exceptions.RequestException as e:
#         print(f"❌ Error comparing content: {e}")
#         return ""

# def check_plagiarism_llama(user_blog: str):
#     with open("dataset.json", "r", encoding="utf-8") as f:
#         dataset = json.load(f)

#     sources = []
#     for entry in dataset:
#         topic = entry.get("topic", "Unknown Topic")
#         for para in entry.get("content", []):
#             prompt = f"Compare the following paragraph with the given blog. If they convey the same meaning or content, reply with only 'Plagiarized'. Otherwise, reply with only 'Original'.\n\nBlog:\n{user_blog}\n\nParagraph:\n{para}"
#             result = query_llama(prompt)

#             if result.lower().strip() == "plagiarized":
#                 sources.append(entry.get("url", "Unknown URL"))
#                 break

#     return {
#         "is_plagiarized": bool(sources),
#         "sources": sources,
#         "mode_used": "llama"
#     }

# def check_plagiarism(title: str, content: str, mode: str = "nltk"):
#     full_text = f"{title.strip()}\n\n{content.strip()}"

#     if mode == "llama":
#         return check_plagiarism_llama(full_text)

#     chunks = chunk_text(full_text)
#     chunk_scores = []
#     matched_sources = []

#     for chunk in chunks:
#         query = chunk.strip()
#         urls = search_snippets_serpapi(query) if mode == "serpapi" else search_snippets_ddg(query)
#         best_score, best_url = 0, None

#         for url in urls:
#             content = scrape_text(url)
#             if content:
#                 ref_embedding = model.encode(content, convert_to_tensor=True)
#                 chunk_embedding = model.encode(chunk, convert_to_tensor=True)
#                 score = float(util.cos_sim(chunk_embedding, ref_embedding))

#                 if score > best_score:
#                     best_score = score
#                     best_url = url

#         threshold = 0.4 if len(chunk.split()) < 10 else 0.6
#         chunk_scores.append(best_score)
#         matched_sources.append(best_url if best_score > threshold else None)

#     avg_score = sum(chunk_scores) / len(chunk_scores) if chunk_scores else 0
#     is_plagiarized = avg_score > 0.5

#     return {
#         "is_plagiarized": is_plagiarized,
#         "average_score": round(avg_score, 2),
#         "sources": matched_sources,
#         "mode_used": mode
#     }

# def format_plain_text_to_html(text: str) -> str:
#     paragraphs = text.strip().split('\n\n')
#     formatted_paragraphs = []

#     for para in paragraphs:
#         lines = para.strip().split('\n')
#         formatted = '<br>'.join(line.strip() for line in lines if line.strip())
#         if formatted:
#             formatted_paragraphs.append(f"<p>{formatted}</p>")

#     return "\n".join(formatted_paragraphs)

# def save_blog(title: str, content: str, author: str):
#     # content_html = format_plain_text_to_html(content)

#     try:
#         with open("blogs.json", "r+", encoding="utf-8") as f:
#             try:
#                 data = json.load(f)
#             except json.JSONDecodeError:
#                 data = []

#             data.append({
#                 "title": title,
#                 "content": content,
#                 "author": author
#             })
#             f.seek(0)
#             f.truncate()
#             json.dump(data, f, indent=2)

#         return {"status": "success"}
#     except Exception as e:
#         return {"status": "error", "message": str(e)}

# def get_all_blogs():
#     try:
#         with open("blogs.json", "r", encoding="utf-8") as f:
#             return json.load(f)
#     except (FileNotFoundError, json.JSONDecodeError):
#         return []

# def get_blog_by_id(blog_id: int):
#     try:
#         with open("blogs.json", "r", encoding="utf-8") as f:
#             blogs = json.load(f)
#             if 0 <= blog_id < len(blogs):
#                 return blogs[blog_id]
#             return {"error": "Blog not found"}
#     except Exception as e:
#         return {"error": str(e)}
#------------------------------------------------------------------------------------------------------

import json
from sentence_transformers import SentenceTransformer, util
from duckduckgo_search import DDGS
from bs4 import BeautifulSoup
import requests
import nltk
import re

nltk.download("punkt")

model = SentenceTransformer("all-MiniLM-L6-v2")
SERP_API_KEY = "b51af3fa02f19b02c6324d46ca4f9979f52d39817ade7fa29206ccac1220335f"
LLAMA_API_URL = "http://localhost:11434/api/generate"

def chunk_text(text, max_tokens=100):
    from nltk.tokenize import sent_tokenize
    sentences = sent_tokenize(text)
    chunks, current_chunk = [], []
    for sentence in sentences:
        current_chunk.append(sentence)
        if len(" ".join(current_chunk).split()) > max_tokens:
            chunks.append(" ".join(current_chunk))
            current_chunk = []
    if current_chunk:
        chunks.append(" ".join(current_chunk))
    return chunks

def search_snippets_ddg(query, max_results=5):
    try:
        with DDGS() as ddgs:
            results = ddgs.text(query, max_results=max_results)
            return [r["href"] for r in results if "href" in r]
    except Exception as e:
        print(f"❌ DDG failed: {e}")
        return []

def search_snippets_serpapi(query, max_results=5):
    try:
        url = "https://serpapi.com/search.json"
        params = {
            "q": query,
            "api_key": SERP_API_KEY,
            "engine": "google"
        }
        response = requests.get(url, params=params)
        data = response.json()
        sources = []
        if "organic_results" in data:
            for item in data["organic_results"][:max_results]:
                link = item.get("link")
                if link:
                    sources.append(link)
        return sources
    except Exception as e:
        print(f"❌ SerpAPI failed: {e}")
        return []

def scrape_text(url):
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        html = requests.get(url, headers=headers, timeout=10).text
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(separator=" ", strip=True)
        text = re.sub(r"\s+", " ", text)
        return text
    except Exception as e:
        print(f"❌ Failed to fetch {url}: {e}")
        return ""

def query_llama(prompt: str) -> str:
    try:
        response = requests.post(
            LLAMA_API_URL,
            json={
                "model": "llama3.2",
                "prompt": prompt,
                "stream": False
            }
        )
        response.raise_for_status()
        return response.json()["response"].strip()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error comparing content: {e}")
        return ""

def check_plagiarism_llama(user_blog: str):
    with open("dataset.json", "r", encoding="utf-8") as f:
        dataset = json.load(f)

    sources = []
    for entry in dataset:
        topic = entry.get("topic", "Unknown Topic")
        for para in entry.get("content", []):
            prompt = f"Compare the following paragraph with the given blog. If they convey the same meaning or content, reply with only 'Plagiarized'. Otherwise, reply with only 'Original'.\n\nBlog:\n{user_blog}\n\nParagraph:\n{para}"
            result = query_llama(prompt)

            if result.lower().strip() == "plagiarized":
                sources.append(entry.get("url", "Unknown URL"))
                break

    return {
        "is_plagiarized": bool(sources),
        "sources": sources,
        "mode_used": "llama"
    }

def check_plagiarism(title: str, content: str, mode: str = "nltk"):
    full_text = f"{title.strip()}\n\n{content.strip()}"

    if mode == "llama":
        return check_plagiarism_llama(full_text)

    chunks = chunk_text(full_text)
    chunk_scores = []
    matched_sources = []

    for chunk in chunks:
        query = chunk.strip()
        urls = search_snippets_serpapi(query) if mode == "serpapi" else search_snippets_ddg(query)
        best_score, best_url = 0, None

        for url in urls:
            content = scrape_text(url)
            if content:
                ref_embedding = model.encode(content, convert_to_tensor=True)
                chunk_embedding = model.encode(chunk, convert_to_tensor=True)
                score = float(util.cos_sim(chunk_embedding, ref_embedding))

                if score > best_score:
                    best_score = score
                    best_url = url

        threshold = 0.4 if len(chunk.split()) < 10 else 0.6
        chunk_scores.append(best_score)
        matched_sources.append(best_url if best_score > threshold else None)

    avg_score = sum(chunk_scores) / len(chunk_scores) if chunk_scores else 0
    is_plagiarized = avg_score > 0.5

    return {
        "is_plagiarized": is_plagiarized,
        "average_score": round(avg_score, 2),
        "sources": matched_sources,
        "mode_used": mode
    }

def format_plain_text_to_html(text: str) -> str:
    paragraphs = text.strip().split('\n\n')
    formatted_paragraphs = []

    for para in paragraphs:
        lines = para.strip().split('\n')
        formatted = '<br>'.join(line.strip() for line in lines if line.strip())
        if formatted:
            formatted_paragraphs.append(f"<p>{formatted}</p>")

    return "\n".join(formatted_paragraphs)

def save_blog(title: str, content: str, author: str):
    content_html = format_plain_text_to_html(content) # 🔥 Use the formatter

    try:
        with open("blogs.json", "r+", encoding="utf-8") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = []

            data.append({
                "title": title,
                "content": content, # Save raw content
                "content_html": content_html, # 🔥 Save HTML content
                "author": author
            })
            f.seek(0)
            f.truncate()
            json.dump(data, f, indent=2)

        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

def get_all_blogs():
    try:
        with open("blogs.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def get_blog_by_id(blog_id: int):
    try:
        with open("blogs.json", "r", encoding="utf-8") as f:
            blogs = json.load(f)
            if 0 <= blog_id < len(blogs):
                return blogs[blog_id]
            return {"error": "Blog not found"}
    except Exception as e:
        return {"error": str(e)}