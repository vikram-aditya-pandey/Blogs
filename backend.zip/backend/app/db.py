def save_blog(title, content, result):
    print("✅ Blog saved:")
    print("Title:", title)
    print("Plagiarism check result:", result)
